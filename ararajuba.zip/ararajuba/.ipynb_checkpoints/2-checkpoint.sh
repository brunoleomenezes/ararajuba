#!/bin/bash

# Extraia somente o que vem depois de "Type: " no arquivo output.txt e salve em um arquivo temporário
sed -n 's/^Type: \(.*\)/\1/p' output.txt > /tmp/patterns.txt

# Salve a primeira linha encontrada como referência
reference=$(head -n 1 /tmp/patterns.txt)

# Compare a referência com as demais linhas
while read line; do
  if [ "$line" != "$reference" ]; then
    echo $line >> output_erros.txt
  fi
done < /tmp/patterns.txt

# Se o arquivo output_erros.txt não estiver vazio, significa que há diferenças entre as linhas
if [ -s output_erros.txt ]; then
  echo "Padrões diferentes encontrados, veja o arquivo output_erros.txt para mais detalhes"
  sh 3.sh # Execute o arquivo 3.sh com o bin/bash
else
  echo "Todos os padrões são iguais"
fi

# Remova o arquivo temporário
rm /tmp/patterns.txt