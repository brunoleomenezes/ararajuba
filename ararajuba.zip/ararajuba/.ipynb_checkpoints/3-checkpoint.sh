#!/bin/bash

# Armazene o padrão a ser procurado
pattern=$(cat output_erros.txt)

# Procurar o padrão em "output.txt"
grep -n "$pattern" output.txt | while read line; do
  # Armazenar o número da linha
  line_number=$(echo "$line" | awk -F: '{print $1}')

  # Exibir a linha encontrada
  echo "$line"

  # Exibir as 12 linhas acima da linha encontrada
  head -n "$line_number" output.txt | tail -n 12
done

# Se o grep não retornou nada, significa que o padrão não foi encontrado
if [ $? -ne 0 ]; then
  echo "O padrão não foi encontrado em output.txt"
fi
sh 4.sh # Execute o arquivo 3.sh com o bin/bash
