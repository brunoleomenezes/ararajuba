#!/bin/bash

# Nome do arquivo de saída
OUTPUT_FILE="output.txt"

# Diretórios que contém arquivos ORC
ORC_DIRS="$(hdfs dfs -ls -R "$1" | grep "\.orc$" | awk '{print $8}' | xargs dirname | sort | uniq)"

# Loop para iterar sobre todos os diretórios ORC
for dir in $ORC_DIRS; do
    # Loop para iterar sobre todos os arquivos ORC no diretório
    for file in "$dir"/*.orc; do
        # Obter o nome do arquivo sem o caminho completo
        filename="$(basename "$file")"

        # Adicionar o nome do arquivo ao arquivo de saída
        echo "####################" >> "$OUTPUT_FILE"
        echo "# File: $filename" >> "$OUTPUT_FILE"
        echo "####################" >> "$OUTPUT_FILE"

        # Executar o comando hive --orcfiledump e capturar as 10 primeiras linhas
        hive --orcfiledump "$file" | head -n 20 >> "$OUTPUT_FILE"
    done
done
sh 2.sh
